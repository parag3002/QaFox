package utility;
import base.*;

public class WriteToExcel
{

	
	
	public WriteToExcel() throws Exception
	{
		
	}
		/*
	//===========================
	public void TestRepostExcel() throws Exception
	{
		
		FileOutputStream FOS = new FileOutputStream("D:\\eclipse-workspace\\TestNG_Maven_QS\\src\\test\\resources\\TestReportExcel\\TestReport.xlsx");
		XSSFWorkbook ReportWorkbook = new XSSFWorkbook();
		XSSFSheet TestReportSheet = ReportWorkbook.createSheet("TestReport");
		
		//XSSFRow TestReportRow = TestReportSheet.createRow(0);
		
		//===========reading test case excel file
		XSSFSheet TestCaseSheet = workbook.getSheet("TestCase1");
		//XSSFRow TestCaseRow = TestCaseSheet.getRow(0);
		//System.out.println(TestCaseRow.getCell(0).toString());
		//TestCaseRow.getCell(0).toString();
		//=========end of reading
		
		int i,j;
		
		for(i=0;i<12;i++)
		{
			XSSFRow TestCaseRow = TestCaseSheet.getRow(i);
			XSSFRow TestReportRow = TestReportSheet.createRow(i);
			for(j=0;j<3;j++)
			{
				TestReportRow.createCell(j).setCellValue(TestCaseRow.getCell(j).toString()); // reading from one excel and writing to another at once
			}
		}
		
		
		ReportWorkbook.write(FOS);
		FOS.close();
	}	
			
			
	//==========================

	*/		
	
	
}
